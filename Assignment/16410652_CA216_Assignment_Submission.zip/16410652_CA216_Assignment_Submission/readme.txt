2017-18 CA216 assignment
16410652 - James O'Neill


I tested this code using the standard terminal and python3 shell. I inserted print statements at various points in the code to see exactly what my program and threads were doing, such as inserting print statements when the barbers were sleeping, when they were woken, when the waiting room was added to, when the waiting room was full, etc. I kept these print statements in the code to allow you to see how my program is running. 

The program accepts user input, which allowed me to test my code, and to allow you to decide how long you want my program to run, and how many barbers you would like to be in the simulation. 

I believe my code works as required, and I am quite certain that I do not have any flaws remaining in my code. 